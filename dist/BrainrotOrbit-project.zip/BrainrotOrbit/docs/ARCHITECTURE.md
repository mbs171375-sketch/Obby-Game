# Architecture and limits

The complete requirements supplied were sections 14–16, plus the request for a vibrant brainrot theme, a curving course with climbs and descents, and the later waiver of Claude review and Studio playtesting. There are no missing sections 1–13 to obtain.

## Project layout

| Location | Purpose |
|---|---|
| `tools/build_place.py` | Deterministic static map and place builder; standard-library Python |
| `src/shared/Config.luau` | Game tuning, cosmetic catalogue, optional creator-owned product IDs and audio |
| `src/shared/Rules.luau` | Engine-independent typed progression, promotions and profile transactions |
| `src/server/Game.server.luau` | Touch events, animated obstacles, progression, rewards, persistence and purchases |
| `src/client/Game.client.luau` | HUD, shop, settings, promotional art, responsive layout and local audio |
| `tests/rules.spec.luau` | Pure rules including receipt replays and interrupted credit use |
| `tests/server.spec.luau` | Production server code running on simulated services and a controllable clock |
| `tests/client.spec.luau` | Production client code running on those services, with UI event simulations |
| `tests/harness.luau` | Isolated deterministic service doubles and scheduler |
| `tests/offline.spec.luau` | Explicit zero-ID fixture with unavailable DataStore |
| `tests/products.spec.luau` | Actual supplied catalogue IDs and ten-credit transactions on service doubles |
| `tests/place.spec.luau` | Real Roblox XML/binary deserialization using Lune/rbx-dom |
| `tests/test_map.py` | Full course topology, default jump reachability and deterministic builds |

The delivered places are standalone. There is no Rojo, runtime HTTP request, third-party plugin, external image, borrowed character model, or dynamically downloaded script. All models and UI art are built from original geometric shapes. Preview rendering and test tools are development-only.

## Course design

The 6,889-stud route interpolates eleven world anchors with curved sideways and vertical offsets. Z increases monotonically, keeping far-apart stages from overlapping. Each world contains a different seeded shuffle of ten obstacle beats, chosen from fourteen categories. Neon islands mark progress and safe positions, but never change the player's respawn point. There is exactly one SpawnLocation in the lobby.

The route checker constructs a graph of platform rectangles and computes edge-to-edge gaps. It conservatively uses WalkSpeed 16, JumpPower 50 and gravity 196.2, with a 0.6-stud launch/landing margin. It excludes moving clouds and fading tiles, so every stage must also have a static free route. This checks geometric feasibility, not input feel, humanoid collision, latency, camera visibility or Roblox's full physics engine.

The fading route warns in amber before disappearing. Its side stones stay solid. The moving-cloud route also has permanent side stones. Lava and lasers are visibly pink; scenery does not have hidden collision. Springs and three-second speed boosts are free. The owning client carries its grounded rider by adding only the contacted platform's translation to the current root position. The server never repositions riders per frame, so it cannot undo walking input or tether a jump. Support queries ignore decoration and reset on jumps, freefall, landing and changed supports. Hidden steps cannot carry players; restoring steps wait until no player body occupies their space. The 100 decorative island undersides are non-colliding to avoid ledges around the playable pads. Rotating anchored hazards additionally scan player-root overlap, since scripted CFrame changes alone cannot reliably produce touch events.

## Trust and data

Clients send only bounded action names and item identifiers. They cannot submit prices, balances, rewards, target stages or an ownership flag. The server validates stage order and proximity, rate-limits actions, and validates products against the configured catalogue. This is not a comprehensive movement anti-cheat: a determined client-side teleport exploit needs additional production movement validation.

Profiles use one DataStore key per player. Wins save as deltas and best progress merges monotonically, preserving newer receipt updates. Local storage operations are serialized. Save outages keep unsaved deltas for retry; unpublished/initially unavailable storage uses an explicitly labelled session-only mode and disables purchases. A server crash before autosave can lose unflushed free rewards. There is no claim of cross-region transaction availability during an outage.

Developer Product receipts add the configured ten durable skip credits and store the purchase ID in the same atomic `UpdateAsync`. Duplicate IDs never add another credit. Unknown products and failed storage operations return `NotProcessedYet`. Purchase completion signals alone never grant Developer Products. Game Pass completion re-queries server-side ownership before granting benefits.

Using a credit creates a durable reservation. A death or disconnect during use refunds it; an interrupted reservation is recovered on next join. If final settlement fails after delivery, recovery may favour the player by returning that credit, rather than destroying a paid entitlement. The receipt ledger fails closed at 4,000 distinct receipts per player; shard/archive receipt records before operating at that scale. It never silently deletes deduplication records.

Client-side product queries obtain the user's regional price; a failed query hides the Buy offer rather than inventing a price. Prices and purchase eligibility still require live Roblox testing. The supplied Speed Coil (2038121195) and Jump Boot (2041634630) IDs are Game Passes; the ten-skip product (3720254856) is a Developer Product.

## Promotions and presentation

The state machine checks a 50-second cadence and queues at most one offer. A card requires a living grounded character, a labelled Safe surface in the lobby or numbered islands, low velocity and two continuous stationary seconds. Movement immediately hides it and retains the queued offer. Menus defer offers. Reminders can be disabled in Settings; the preference is saved when storage works. Coil and skip offers alternate, with speed/gravity alternating within coil offers. Already-owned or unavailable products are not advertised. There are no random paid rewards, urgency countdowns, fabricated discounts or automatic checkouts. Official Roblox prompts are opened only by explicit Buy actions. Platform purchase permissions remain enforced by Roblox.

The selected soundtrack is user-supplied Roblox audio asset 134764779929866 (Brainrot Rap). Its exact SoundId and mute handling pass simulation, but live playback and experience permissions are unverified. A public metadata request was blocked by this cloud network with HTTP 403; this does not establish an invalid asset. Clearing MusicTracks selects an original 132 BPM percussion sequence using bundled samples. Cosmetics provide body colour accents, a companion and trail; they do not replace the player's avatar body or clothing. Reduced motion removes UI tweening and confetti and restores the 27 dancing brainrot models to their static poses; moving gameplay obstacles remain active.

The scene contains 6,292 BaseParts, including the spawn. Decorative objects do not cast shadows. Streaming is disabled for predictable first-launch behaviour. Low-end mobile FPS, camera comfort and touch ergonomics remain unverified; this offline suite cannot establish them.

## Robux-only shop update

Coin rewards, coin UI and coin cosmetic purchase actions are removed. Legacy profile fields remain readable. Pass ownership unlocks independent Speed/Gravity controls without equipping on join. The server gates the actual movement benefits on ownership and equipment: Humanoid WalkSpeed 32 and JumpPower 100. Confirmed purchases auto-equip their boost; selected effects survive respawn. All shop Buy controls request official Roblox prompts. Existing owners are labelled and Buy re-equips after checking ownership; owned passes cannot be charged twice.

A skip purchase durably grants ten stage credits. A new receipt attempts a single ten-stage delivery from a safe active run; otherwise credits await manual use. Reservations store both token and quantity, so interruption refunds the entire amount. Delivery caps at stage 101 and preserves the unused balance. Replayed receipts do not auto-deliver again. Old pending reservations without a quantity recover one credit.
